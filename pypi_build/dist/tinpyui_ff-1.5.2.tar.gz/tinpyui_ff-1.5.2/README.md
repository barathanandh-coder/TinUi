# TinPyUI (`tinpyui-ff`)

> Official Python type stubs and CLI integration for **TinPyUI v1.5.2** — the Zero-DOM WebAssembly UI framework with Pythonic syntax.

[![pypi](https://img.shields.io/badge/pypi-tinpyui--ff-v1.5.2-blue)](https://pypi.org/project/tinpyui-ff/)
[![license](https://img.shields.io/badge/license-MIT-green)](https://github.com/barathanandh-coder/tinui)

---

## 🐍 Python Installation & Usage

Install the PyPI package:

```bash
pip install tinpyui-ff
```

### Flask Server Integration

TinPyUI applications compile into a static Wasm engine (`public/app.ir.json`, `tinui_engine.wasm`, `index.html`) that can be served seamlessly from any Python backend such as Flask:

```python
from flask import Flask, send_from_directory

app = Flask(__name__, static_folder='public')

@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory(app.static_folder, path)

if __name__ == '__main__':
    print("[Info] Starting TinPyUI Flask Server on http://localhost:5000")
    app.run(debug=True, port=5000)
```

---

## ⚡️ Pythonic `.tin` Syntax Blueprint

Write UI components using indentation-based Pythonic syntax:

```text
component Main():
    AnimatedBackground(effect="cyber-wave", primaryColor="neon-purple", secondaryColor="neon-cyan"):
        Navbar(padding=20, blur=true):
            Row(align="center", justify="space-between", width="full"):
                Text(text="TinPyUI App", color="neon-cyan", weight="bold")
                Row(gap=30, color="white"):
                    NavLink(text="Features")
                    NavLink(text="Docs")

        Section(align="center", paddingY=100, maxWidth=800, justify="center"):
            GradientText(text="The Zero-DOM Wasm Engine", gradient=["neon-cyan", "neon-purple"], size="hero")
            Text(text="Build high-performance web applications with Pythonic DSL.", size="large", color="white", marginTop=20)
            
            Row(gap=20, align="center", justify="center", marginTop=40):
                Button(text="Get Started", variant="solid", glow="neon-cyan", radius="pill")
```

---

## 📄 Repository & Documentation
For full documentation, CLI guides, and WebAssembly engine details, visit the main GitHub repository:
[github.com/barathanandh-coder/tinui](https://github.com/barathanandh-coder/tinui)
